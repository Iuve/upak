void nullacq ()
{
}
