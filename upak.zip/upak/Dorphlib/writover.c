#include <stdio.h>

void writover_(char *s)
{
   printf("%s\r",s);
}
