void shared_wipe__(void)
{
}
