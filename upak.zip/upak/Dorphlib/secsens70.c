#include <time.h>

void secsens70_(time_t *tod)
{
   time(tod);
}
